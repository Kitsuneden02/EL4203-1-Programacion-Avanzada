import P1

P1.probar_trie()